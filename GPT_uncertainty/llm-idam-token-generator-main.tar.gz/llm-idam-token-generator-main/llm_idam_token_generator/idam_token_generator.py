"""
Utility to generate the IDAM access token for LLM service app
"""
import base64
import os
import jwt
import boto3
import requests
import uuid
import datetime
from llm_idam_token_generator.utils.constants import APP_CLIENT_ID, APP_CLIENT_SECRET, AWS_ACCESS_URL, IDAM_TOKEN_URL, \
    LLM_APP_AUDIENCE, LOG_LEVEL
from llm_idam_token_generator.utils.Logger import Logger

logger = Logger(__name__)
logger.set_level(LOG_LEVEL)
logger.set_global_client_id(APP_CLIENT_ID)

token = ""


def get_unique_number():
    return uuid.uuid4()


def validate_environment_variable():
    """
    Validate if an environment variable is present.

    Args:
    - env_variable (str): The name of the environment variable to validate.

    Raises:
    - ValueError: If the environment variable is not present.
    """
    required_env_variables = ['APP_CLIENT_ID', 'APP_CLIENT_SECRET']
    try:
        for env_var in required_env_variables:
            os_env_var = os.environ.get(env_var)
            if os_env_var is None or len(os_env_var.strip()) == 0 or os_env_var == '':
                raise ValueError(f"Environment variable '{env_var}' is not set.")
        logger.info("All required environment variables are present.")
    except ValueError as e:
        logger.error(f"Error: {e}")
        exit(1)


def get_access_token():
    """
    Input : IDAM Application Client ID and Client secret
    :return: Access token
    """
    payload = f'grant_type=client_credentials&client_id={APP_CLIENT_ID}&client_secret={APP_CLIENT_SECRET}&scope={get_unique_number()}'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    try:
        response_data = requests.request("POST", IDAM_TOKEN_URL, headers=headers, data=payload, verify=False)
        response_data.raise_for_status()
        if response_data is not None and response_data.ok:
            access_token = response_data.json()['access_token']
            logger.info("IDAM Access Token is generated")
            return access_token
    except requests.RequestException as e:
        logger.error(f"Error sending POST request to {IDAM_TOKEN_URL}: {e}")
        raise


def get_exchange_token(access_token):
    try:
        # Token exchange.
        payload = f'grant_type=token_exchange&token={access_token}&audience={LLM_APP_AUDIENCE}&scope={get_unique_number()}'
        basic_auth_creds = f"{APP_CLIENT_ID}:{APP_CLIENT_SECRET}"
        basic_auth_creds = base64.b64encode(basic_auth_creds.encode()).decode("ascii")
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': f'Basic {basic_auth_creds}'
        }
        response_data = requests.request("POST", IDAM_TOKEN_URL, headers=headers, data=payload, verify=False)
        response_data.raise_for_status()
        if response_data is not None:
            exchange_token = response_data.json()['access_token']
            logger.info(f"IDAM Exchange Access Token is generated")
            return exchange_token
    except requests.RequestException as e:
        logger.error(f"Error sending POST request to {IDAM_TOKEN_URL} for exchange token: {e}")
        raise


def get_llm_access_token():
    global token
    try:
        validate_environment_variable()
        access_token = get_access_token()
        if access_token is not None:
            token = get_exchange_token(access_token)
        return token
    except requests.exceptions.HTTPError as e:
        logger.error(f"Failed to get the IDAM Access Token. Due to HTTP error occurred: {e}")
    except requests.RequestException as e:
        logger.error(f"Failed to get the IDAM Access Token. Due to Request error occurred: {e}")


def get_boto3_session():
    try:
        # logger.set_global_client_id(APP_CLIENT_ID)
        # validate_env_list()
        exchange_token = get_llm_access_token()
        if exchange_token is not None:
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {exchange_token}'
            }
            response_data = requests.request("GET", AWS_ACCESS_URL, headers=headers, verify=False)
            if response_data is not None:
                aws_cred = response_data.json()
                logger.info("AWS Access credentials are generated")
            else:
                logger.error("Failed to get AWS credentials.")

            return boto3.Session(
                aws_access_key_id=aws_cred['AccessKeyId'],
                aws_secret_access_key=aws_cred['SecretAccessKey'],
                aws_session_token=aws_cred['SessionToken']
            )
    except requests.exceptions.HTTPError as e:
        logger.error(f"Failed to get the AWS boto3 session. Due to HTTP error occurred: {e}")
    except requests.RequestException as e:
        logger.error(f"Failed to get the AWS boto3 session. Due to HTTP error occurred: {e}")


def is_valid_token():
    """
  This function checks if a JWT token is expired.

  Returns:
      bool: True if the token is valid, False otherwise.
  """
    global token
    try:
        if token is not None and token != "":
            # Use PyJWT to decode the token
            decoded_token = jwt.decode(token, options={"verify_signature": False})
            exp_time = decoded_token.get('exp')
            logger.info(f"Expiry_time: {exp_time}")
            if exp_time:
                exp_time = datetime.datetime.fromtimestamp(exp_time, datetime.UTC)
                return exp_time > datetime.datetime.now(datetime.UTC)
            logger.info("JWT token is VALID")
            return True
        else:
            return False
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as ex:
        # Handle decode errors (e.g., expired or invalid token)
        logger.info("JWT token expired . Please re-create")
        return False
    except Exception as e:
        # Handle other potential exceptions
        logger.error(f"An unexpected error occurred: {e}")
        return False


def get_idam_token():
    """
    This function get the token. if a JWT token is expired.
    Create new one JWT token.

    Returns:
        string : JWT token.
    """
    global token
    if not is_valid_token():
        logger.info("Generating new token.")
        token = get_llm_access_token()
        return token
    else:
        return token
