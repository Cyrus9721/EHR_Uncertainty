
#  logs.py
#
#  Copyright (c) 2021 by GEHC Company. All rights reserved.
#
#  The copyright to the computer software herein is the property of
#  GEHC Company. The software may be used and/or copied only
#  with the written permission of GEHC Company or in accordance
#  with the terms and conditions stipulated in the agreement/contract
#  under which the software has been supplied.

import logging
import time


class Logger:
    """
    A logging class designed to be used across Edison AI Model Services.
    Initialize a new instance of this class at the top of each .py file with:
        logger = Logger(__name__)
    This will create a logger instance that is named after the current module.
    The name of the module will show up with any logs in the module, making debugging easier.
    Logger instances expose methods to log at several levels that are identical to the standard logger methods.
    For example, to log debug messages using Logger:
        logger = Logger(__name__)
        logger.debug("Log message")
    """

    def __init__(self, name=None):
        """
        Initialize an Logger instance. Each instance will contain two logging.Logger objects:
            - _root_logger: always references the same Python root logger.
            - _logger: references a logger instance created with the name argument.
        Actual log messages are logged against _logger for each Logger instance.
        Configuration changes, formatters, and handlers are added to _root_logger.
        Since every _logger inherits from _root_logger, the configuration changes to _root_logger propagate down to all _loggers for all Logger instances.
        Args:
            name: {string}  name to associate with the Logger instance.
                            This name is used when creating the named _logger instance.
                            Usually this is set to __name__ for each Python file.
        """
        self._root_logger = logging.getLogger()
        self._root_logger.setLevel(logging.INFO)

        formatter = LogFormatter()
        handler = logging.StreamHandler()
        handler.setFormatter(formatter)
        if len(self._root_logger.handlers) == 0:
            self._root_logger.addHandler(handler)

        if name is None:
            self._logger = self._root_logger
        else:
            self._logger = logging.getLogger(name)

    def set_global_client_id(self, client_id):
        """
        Sets a global experiment ID to log across all Logger instances.
        Every time this method is called, it overwrites the global experiment ID.
        Messages logged to any Logger instance will use the last set global experiment ID.
        In practical usage, this method should be called exactly once per services - to set the experiment ID after it is extracted from the incoming request.
        Args:
            client_id: Unique ID of an Edison AI experiment.
        """
        new_handler = logging.StreamHandler()
        new_formatter = LogFormatter(client_id)
        new_handler.setFormatter(new_formatter)
        self._root_logger.handlers = []
        self._root_logger.addHandler(new_handler)

    def info(self, msg):
        """ Log a message to the at the INFO level """
        self._logger.info(msg)

    def warn(self, msg):
        self._logger.warning(msg)

    def error(self, msg):
        self._logger.error(msg)

    def critical(self, msg):
        self._logger.critical(msg)

    def debug(self, msg):
        self._logger.debug(msg)

    def performence(self):
        CURRENT_TIME_IN_MILLIS = lambda: int(round(time.time() * 1000))
        # self._logger.info(CURRENT_TIME_IN_MILLIS)
        return CURRENT_TIME_IN_MILLIS

    def set_level(self, target_log_level):
        self._root_logger.setLevel(target_log_level)


class LogFormatter(logging.Formatter):
    """
    Log formatter that adds the following useful information to every log record:
        - Log level
        - Process ID
        - Module name
        - IDAM App Client ID
    """

    def __init__(self, client_id=None):
        """
        Initialize an LogFormatter instance.
        Args:
            client_id: {string} ID for an Edison AI experiment. Default is None.
        """
        base_format = 'PID:%(process)d %(levelname)s %(name)s - Client ID: %(client_id)s - %(message)s'
        super(LogFormatter, self).__init__(fmt=base_format)
        self._client_id = client_id

    def format(self, record):
        """
        Overrides logging.Formatter.format() to include experiment ID in the log record.
        Args:
            record: LogRecord object
        Returns: the specified record as text.
        """
        record.client_id = self._client_id
        return super(LogFormatter, self).format(record)