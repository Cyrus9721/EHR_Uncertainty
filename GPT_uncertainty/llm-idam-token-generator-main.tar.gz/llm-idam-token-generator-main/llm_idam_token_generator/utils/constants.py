#  constants.py
#
#  Copyright (c) 2021 by General Electric Company. All rights reserved.
#
#  The copyright to the computer software herein is the property of
#  General Electric Company. The software may be used and/or copied only
#  with the written permission of General Electric Company or in accordance
#  with the terms and conditions stipulated in the agreement/contract
#  under which the software has been supplied.
import logging
import os
LOG_LEVEL = os.getenv('LOG_LEVEL', logging.INFO)
APP_CLIENT_ID = os.environ.get('APP_CLIENT_ID')
APP_CLIENT_SECRET = os.environ.get('APP_CLIENT_SECRET')
IDAM_TOKEN_URL = os.environ.get('IDAM_TOKEN_URL', 'https://idam.gehealthcloud.io/oauth2/token')
LLM_APP_AUDIENCE = os.environ.get('LLM_APP_AUDIENCE', '0_b2dJB20TBhxzLIHCMzSG4RiQYa')
aws_region = os.environ.get('AWS_REGION', 'us-west-2')
AWS_ACCESS_URL = os.environ.get('AWS_ACCESS_URL',
                                'https://7z6vsqc0c1.execute-api.us-west-2.amazonaws.com/default/getassumelrole')

X_FORM_URL_ENCODED_HEADERS = {'Content-Type': 'application/x-www-form-urlencoded'}